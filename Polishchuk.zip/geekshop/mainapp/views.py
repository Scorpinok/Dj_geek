from django.shortcuts import render, get_object_or_404
import datetime

from mainapp.models import Product, ProductCategory


# Create your views here.
def main(request):
    content = {
        "title": 'Главная',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/index.html', content)


def products(request):
    links_menu = ProductCategory.objects.all()
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        'links_menu': links_menu,
    }
    return render(request, 'mainapp/products.html', content)


def categ(request, pk=None):
    links_menu = ProductCategory.objects.all()
    content = {
        "title": 'Товар',
        "date": datetime.date.today(),
        'links_menu': links_menu,
        "products": product_list,
    }
    if pk:
        product_item = Product.objects.get(pk=pk)
        content['product'] = product_item
    return render(request, 'mainapp/catalog/prod_item.html', content)

def catalog(request, pk=None):
    title = 'продукты'
    links_menu = ProductCategory.objects.get(pk=pk)
    product_list = Product.objects.filter(category__pk=pk).order_by('price')
    content = {
        'title': title,
        'category': {"pk": pk,"links_menu":links_menu},
        'products': product_list,
    }
    return render(request, 'mainapp/products.html', content)

def contacts(request):
    content = {
        "title": 'Контакты',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/contacts.html', content)
