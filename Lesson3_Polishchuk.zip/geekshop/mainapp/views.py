from django.shortcuts import render
import datetime

from mainapp.models import Product


# Create your views here.
def main(request):
    content = {
        "title": 'Главная',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/index.html', content)


def products(request):
    product_list = Product.objects.all()
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        "products": product_list,
    }
    return render(request, 'mainapp/products.html', content)


def catalog(request, pk=None):
    product_list = Product.objects.all()
    content = {
        "date": datetime.date.today(),
        "products": product_list,
    }
    if pk:
        product_item = Product.objects.get(pk=pk)
        content['product'] = product_item
    return render(request, 'mainapp/catalog/prod_item.html', content)


def contacts(request):
    content = {
        "title": 'Контакты',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/contacts.html', content)
