from django.shortcuts import render, get_object_or_404
import datetime

from mainapp.models import Product, ProductCategory
from basketapp.models import Basket

import random


def get_basket(user):
    if user.is_authenticated:
        return Basket.objects.filter(user=user)
    else:
        return []


def get_hot_product():
    products = Product.objects.all()
    return random.sample(list(products),1)[0]


def get_same_products(hot_product):
    same_products = Product.objects.filter(category=hot_product.category).exclude(pk=hot_product.pk)[:3]
    return same_products


def main(request):
    content = {
        "title": 'Главная',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/index.html', content)

def products(request):
    basket = get_basket(request.user)

    hot_product = get_hot_product()
    same_products = get_same_products(hot_product)

    links_menu = ProductCategory.objects.all()
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        'links_menu': links_menu,
        'basket': basket,
        'same_products': same_products,
        'hot_product': hot_product,
    }
    return render(request, 'mainapp/products.html', content)


def product(request, pk=None):
    basket = get_basket(request.user)

    links_menu = ProductCategory.objects.all()
    product_item = get_object_or_404(Product, pk=pk)
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        'links_menu': links_menu,
        'product': product_item,
        'basket': basket,
    }
    return render(request, 'mainapp/catalog/prod_item.html', content)


def catalog(request, pk=None):
    basket = get_basket(request.user)

    hot_product = get_hot_product()
    same_products = get_same_products(hot_product)

    title = 'продукты'
    links_menu = ProductCategory.objects.get(pk=pk)
    product_list = Product.objects.filter(category__pk=pk).order_by('price')
    content = {
        'title': title,
        'category': {"pk": pk, "links_menu": links_menu},
        'products': product_list,
        'basket': basket,
        'same_products': same_products,
        'hot_product': hot_product,
    }
    return render(request, 'mainapp/products.html', content)


def contacts(request):
    content = {
        "title": 'Контакты',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/contacts.html', content)
