from django.shortcuts  import get_object_or_404, render, HttpResponseRedirect
from django.contrib.auth.decorators  import user_passes_test
from django.views.generic.edit  import CreateView, UpdateView, DeleteView
from django.views.generic.list  import ListView
from django.views.generic.detail  import DetailView
from django.utils.decorators  import method_decorator
from django.urls  import reverse_lazy, reverse

from authapp.models  import ShopUser
from mainapp.models  import Product, ProductCategory
from authapp.forms  import ShopUserRegisterForm, ShopUserEditForm
from adminapp.forms  import  ShopUserAdminEditForm, ProductCategoryEditForm, ProductEditForm


class ProductCategoryDeleteView(DeleteView):
    model = ProductCategory
    template_name =  'adminapp/category_delete.html'
    success_url = reverse_lazy('admin:categories')

    def delete (self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.is_active =  False
        self.object.save()
        return HttpResponseRedirect(self.get_success_url())

class ProductCategoryCreateView(CreateView):
    model = ProductCategory
    template_name = 'adminapp/category_update.html'
    success_url = reverse_lazy('admin:categories')
    fields = '__all__'

class ProductCategoryUpdateView(UpdateView):
    model = ProductCategory
    template_name =  'adminapp/category_update.html'
    success_url = reverse_lazy('admin:categories')
    fields =  '__all__'

    def get_context_data (self, **kwargs):
        context = super().get_context_data(**kwargs)
        context[ 'title' ] =  'категории/редактирование'
        return context


class UsersListView(ListView):
    model = ShopUser
    template_name = 'adminapp/users.html'

    @method_decorator(user_passes_test(lambda u: u.is_superuser))
    def dispatch (self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

class UserCreateView(CreateView):
    model = ShopUser
    template_name = 'adminapp/user_update.html'
    success_url = reverse_lazy('admin:users')
    form_class = ShopUserRegisterForm

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super(UserCreateView, self).form_valid(form)

class UserUpdateView(UpdateView):
    model = ShopUser
    template_name = 'adminapp/user_update.html'
    success_url = reverse_lazy('admin:users')
    form_class = ShopUserEditForm

class UserDeleteView(DeleteView):
    model = ShopUser
    template_name =  'adminapp/user_delete.html'
    success_url = reverse_lazy('admin:users')

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.is_active =  False
        self.object.save()
        return HttpResponseRedirect(self.get_success_url())

def categories(request):
    title =  'админка/категории'
    categories_list = ProductCategory.objects.all()
    content = {
        'title' : title,
        'objects' : categories_list
    }
    return render(request,  'adminapp/categories.html' , content)


def products(request, pk):
    title =  'админка/продукт'
    category = get_object_or_404(ProductCategory, pk=pk)
    products_list = Product.objects.filter(category__pk=pk).order_by( 'name' )
    content = {
        'title' : title,
        'category' : category,
        'objects' : products_list,
    }
    return render(request,  'adminapp/products.html' , content)


class ProductCreateView(CreateView):
    model = Product
    template_name = 'adminapp/category_update.html'
    fields = '__all__'

    def get_success_url(self):
        self.object = self.get_object()
        return reverse_lazy('admin:products', kwargs={'pk': self.get_object().category.pk})

class ProductUpdateView(UpdateView):
    model = Product
    template_name = 'adminapp/product_update.html'
    fields =  '__all__'

    def get_success_url(self):
        self.object = self.get_object()
        return reverse_lazy('admin:products', kwargs={'pk': self.get_object().category.pk})


class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'adminapp/product_delete.html'

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.is_active =  False
        self.object.save()
        return HttpResponseRedirect(reverse_lazy('admin:products', kwargs={'pk': self.get_object().category.pk}))

class ProductDetailView(DetailView):
    model = Product
    template_name = 'adminapp/product_read.html'