from django.shortcuts import render, get_object_or_404
import datetime

from mainapp.models import Product, ProductCategory
from basketapp.models import Basket

# Create your views here.
def main(request):
    content = {
        "title": 'Главная',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/index.html', content)


def products(request):
    basket = []
    if request.user.is_authenticated:
        basket = Basket.objects.filter(user=request.user)

    links_menu = ProductCategory.objects.all()
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        'links_menu': links_menu,
        'basket': basket,
    }
    return render(request, 'mainapp/products.html', content)


def product(request, pk):
    basket = []
    if request.user.is_authenticated:
        basket = Basket.objects.filter(user=request.user)

    links_menu = ProductCategory.objects.all()
    product_item = get_object_or_404(Product, pk=pk)
    content = {
        "title": 'Каталог',
        "date": datetime.date.today(),
        'links_menu': links_menu,
        'product': product_item,
        'basket': basket,
    }
    return render(request, 'mainapp/catalog/prod_item.html', content)


def catalog(request, pk=None):
    basket = []
    if request.user.is_authenticated:
        basket = Basket.objects.filter(user=request.user)

    title = 'продукты'
    links_menu = ProductCategory.objects.get(pk=pk)
    product_list = Product.objects.filter(category__pk=pk).order_by('price')
    content = {
        'title': title,
        'category': {"pk": pk,"links_menu":links_menu},
        'products': product_list,
        'basket': basket,
    }
    return render(request, 'mainapp/products.html', content)

def contacts(request):
    content = {
        "title": 'Контакты',
        "date": datetime.date.today(),
    }
    return render(request, 'mainapp/contacts.html', content)
