import json
import os, codecs

from django.core.management.base import BaseCommand

from authapp.models import ShopUser
from mainapp.models import Product, ProductCategory

JSON_PATH = 'mainapp/json'


def loadFromJSON(file_name):
    with codecs.open(os.path.join(JSON_PATH, file_name + '.json'), 'r', encoding='utf-8') as infile:
        return json.load(infile)


class Command(BaseCommand):
    help = 'Fill DB new data'

    def handle(self, *args, **options):
        categories = loadFromJSON('categories')

        ProductCategory.objects.all().delete()
        for category in categories:
            new_category = ProductCategory(**category)
            new_category.save()

        products = loadFromJSON('products')

        Product.objects.all().delete()
        for product in products:
            category_name = product["category"]
            _category = ProductCategory.objects.get(name=category_name)  # получаем категорию по имени
            product['category'] = _category  # заменяем название категории объектом
            new_category = Product(**product)
            new_category.save()

        # создаем супер пользователя при помощи менеджера модели
        try:
            ShopUser.objects.get(username='django')
        except ShopUser.DoesNotExist:
            ShopUser.objects.create_superuser('django', 'django@geekshop.local', 'geekbrains')
