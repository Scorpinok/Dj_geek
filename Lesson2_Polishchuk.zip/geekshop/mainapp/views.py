from django.shortcuts import render
import datetime

# Create your views here.
def main(request):
    content = {
          "title" : 'Главная',
          "date"  : datetime.date.today(),
    }
    return render(request,'mainapp/index.html', content)

def products(request):
    content = {
        "title" : 'Каталог',
        "date": datetime.date.today(),
    }
    return render(request,'mainapp/products.html', content)

def contacts(request):
    content = {
        "title" : 'Контакты',
        "date": datetime.date.today(),
    }
    return render(request,'mainapp/contacts.html', content)
    
def apple(request):
    link_menu = [
        {'href':'apple', 'name':'Яблоко'},
        {'href': 'orange', 'name': 'Апельсин'},
        {'href': 'banana', 'name': 'Банан'},
    ]
    content = {
        "link_menu": link_menu,
        "title": 'Характеристика яблока',
        "date": datetime.date.today(),
    }
    return render(request,'mainapp/catalog/apple.html', content)
    
def orange(request):
    link_menu = [
        {'href':'apple', 'name':'Яблоко'},
        {'href': 'orange', 'name': 'Апельсин'},
        {'href': 'banana', 'name': 'Банан'},
    ]
    content = {
        "link_menu": link_menu,
        "title": 'Характеристика апельсина',
        "date": datetime.date.today(),
    }
    return render(request,'mainapp/catalog/orange.html', content)
 
def banana(request):
    link_menu = [
        {'href':'apple', 'name':'Яблоко'},
        {'href': 'orange', 'name': 'Апельсин'},
        {'href': 'banana', 'name': 'Банан'},
    ]
    content = {
        "link_menu": link_menu,
        "title": 'Характеристика банана',
        "date": datetime.date.today(),
    }
    return render(request,'mainapp/catalog/banana.html', content)